package model;

public class Item {
    private int id;
    private String itemName;
    private int totalItems;
    private int issuedItems;
    private int returnedItems;
    private int itemsLeft;

    // Constructors
    public Item() {}

    public Item(int id, String itemName, int totalItems, int issuedItems, int returnedItems, int itemsLeft) {
        this.id = id;
        this.itemName = itemName;
        this.totalItems = totalItems;
        this.issuedItems = issuedItems;
        this.returnedItems = returnedItems;
        this.itemsLeft = itemsLeft;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }

    public int getIssuedItems() {
        return issuedItems;
    }

    public void setIssuedItems(int issuedItems) {
        this.issuedItems = issuedItems;
    }

    public int getReturnedItems() {
        return returnedItems;
    }

    public void setReturnedItems(int returnedItems) {
        this.returnedItems = returnedItems;
    }

    public int getItemsLeft() {
        return itemsLeft;
    }

    public void setItemsLeft(int itemsLeft) {
        this.itemsLeft = itemsLeft;
    }
}
