package model;

public class Campdetails {
	    private int id; // Auto-increment primary key
	    private String campName;
	    private String startDate; // Store as String if parsing later
	    private String endDate;
	    private String location;
	    private String description;
	    private double registrationFee;

	    // Getters and Setters

	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	  

	    public String getCampName() {
	        return campName;
	    }

	    public void setCampName(String campName) {
	        this.campName = campName;
	    }

	    public String getStartDate() {
	        return startDate;
	    }

	    public void setStartDate(String startDate) {
	        this.startDate = startDate;
	    }

	    public String getEndDate() {
	        return endDate;
	    }

	    public void setEndDate(String endDate) {
	        this.endDate = endDate;
	    }

	    public String getLocation() {
	        return location;
	    }

	    public void setLocation(String location) {
	        this.location = location;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public double getRegistrationFee() {
	        return registrationFee;
	    }

	    public void setRegistrationFee(double registrationFee) {
	        this.registrationFee = registrationFee;
	    }
	    
	    @Override
	    public String toString() {
	        return "Campdetails [id=" + id + ", campName=" + campName +
	               ", startDate=" + startDate + ", endDate=" + endDate + ", location=" + location +
	               ", description=" + description + ", registrationFee=" + registrationFee + "]";
	    }
	    
}
