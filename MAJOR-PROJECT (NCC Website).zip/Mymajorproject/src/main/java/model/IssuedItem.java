package model;
import java.sql.Date;
public class IssuedItem {

	 private String cadetId;
	    private String name;
	    private String itemName;
	    private int quantity;
	    private Date returnDate;
	    private String remarks;
	    private String status;

	    // Constructor
	   

		public String getCadetId() {
			return cadetId;
		}

		public void setCadetId(String cadetId) {
			this.cadetId = cadetId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getItemName() {
			return itemName;
		}

		public void setItemName(String itemName) {
			this.itemName = itemName;
		}

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}

		public Date getReturnDate() {
			return returnDate;
		}

		public void setReturnDate(Date returnDate) {
			this.returnDate = returnDate;
		}

		public String getRemarks() {
			return remarks;
		}

		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
	    
	    
}
