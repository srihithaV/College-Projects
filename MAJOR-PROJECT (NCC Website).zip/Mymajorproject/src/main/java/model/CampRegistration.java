package model;
import java.sql.Date;

public class CampRegistration {
    private String campName;
    private String regimentalId;
    private double totalAmount;
    private String status;
    private Date startDate;
    private Date endDate;
    private int cadetCount;

    public String getCampName() { return campName; }
    public void setCampName(String campName) { this.campName = campName; }

    public String getRegimentalId() { return regimentalId; }
    public void setRegimentalId(String regimentalId) { this.regimentalId = regimentalId; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Date getStartDate() { return startDate; }
    public void setStartDate(Date startDate) { this.startDate = startDate; }

    public Date getEndDate() { return endDate; }
    public void setEndDate(Date endDate) { this.endDate = endDate; }
    
    
    public int getCadetCount() {
        return cadetCount;
    }

    public void setCadetCount(int cadetCount) {
        this.cadetCount = cadetCount;
    }
}
