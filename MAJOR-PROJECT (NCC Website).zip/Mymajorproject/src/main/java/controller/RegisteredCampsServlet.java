package controller;

import Dao.CampRegistrationDAO;
import model.CampRegistration;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/RegisteredCampsServlet")
public class RegisteredCampsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisteredCampsServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        // If no user is logged in, redirect to login page
        if (user == null) {
            response.sendRedirect("login.html");
            return;
        }

        // Get the regimental ID of the logged-in cadet
        String regimentalId = user.getRegimental_id();

        // Use DAO to get the registered camps for the cadet
        CampRegistrationDAO dao = new CampRegistrationDAO();
        List<CampRegistration> registeredCamps = dao.getRegisteredCampsForCadet(regimentalId);
        

        // Set the list of registered camps as an attribute for the JSP
        request.setAttribute("registeredCamps", registeredCamps);

        // Forward the request to the registeredcamps.jsp page
        request.getRequestDispatcher("registeredcamps.jsp").forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // For POST request, just redirect to doGet
        doGet(request, response);
    }
}
