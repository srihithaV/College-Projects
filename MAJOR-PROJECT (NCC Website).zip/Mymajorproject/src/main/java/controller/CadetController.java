package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

import Dao.UserDAO;
import model.User;

/**
 * Servlet implementation class CadetController
 */
@WebServlet("/CadetController")
public class CadetController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserDAO userDAO;

	public void init() {
		userDAO = new UserDAO();
	}

	// Handle GET request to show only pending cadets
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<User> pendingCadets = userDAO.getPendingCadets();
		  System.out.println("Cadets Retrieved: " + pendingCadets.size()); // Debugging line
		request.setAttribute("cadets", pendingCadets);

		// Forward to JSP
		request.getRequestDispatcher("viewCadets.jsp").forward(request, response);
	}

	// Handle POST request for Accept or Reject
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			int status = Integer.parseInt(request.getParameter("status")); // 1 = Accept, -1 = Reject

			userDAO.updateCadetStatus(id, status);

			// After updating status, redirect to refresh the list
			response.sendRedirect("CadetController");
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Error occurred while processing cadet status.");
		}
	}
}
