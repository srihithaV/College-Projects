package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import Dao.StockDAO;
import model.StockItem;
import java.io.IOException;
import java.util.List;

@WebServlet("/ViewStockServlet")
public class ViewStockServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        StockDAO dao = new StockDAO();
        List<StockItem> stockList = dao.getAllStockItems();
        request.setAttribute("stockList", stockList);
        request.getRequestDispatcher("viewStock.jsp").forward(request, response);
    }
}
