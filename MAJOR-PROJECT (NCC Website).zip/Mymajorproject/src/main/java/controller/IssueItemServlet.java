package controller;

import Dao.ItemDAO;
import model.IssuedItem;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Date;

@WebServlet("/IssueItemServlet")
public class IssueItemServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public IssueItemServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cadetId = request.getParameter("cadet_id");
        String name = request.getParameter("name");
        String itemName = request.getParameter("item_name");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        Date returnDate = Date.valueOf(request.getParameter("return_date"));
        String remarks = request.getParameter("remarks");

        
        IssuedItem item = new IssuedItem();
        item.setCadetId(cadetId);
        item.setName(name);
        item.setItemName(itemName);
        item.setQuantity(quantity);
        item.setReturnDate(returnDate);
        item.setRemarks(remarks);
        item.setStatus("not returned");


        ItemDAO dao = new ItemDAO();
        boolean success = dao.issueItem(item);

        if (success) {
            response.sendRedirect("issue_success.jsp");
        } else {
            response.sendRedirect("issue_failed.jsp");
        }
    }

    // Optional: remove if not used
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
}
