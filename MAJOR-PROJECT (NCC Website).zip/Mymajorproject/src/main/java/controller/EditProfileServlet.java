package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.EditableUser;
import model.User;
import Dao.UserDAO;

import java.io.IOException;

@WebServlet("/EditProfileServlet")
public class EditProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public EditProfileServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirect to edit profile form on GET
        response.sendRedirect("editprofile.jsp");
    }

    /**
     * Handles POST request to update user's profile.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Read form data
        int userId = Integer.parseInt(request.getParameter("userId"));
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String gender = request.getParameter("gender");
        String qualification = request.getParameter("qualification");

        // Create editable user
        EditableUser updatedUser = new EditableUser(userId, username, email, phone, address, gender, qualification);

        UserDAO userDAO = new UserDAO();
        boolean isUpdated = userDAO.updateUserProfile(updatedUser);

        if (isUpdated) {
            // Update the existing User object in session
            User sessionUser = (User) request.getSession().getAttribute("user");
            if (sessionUser != null) {
                sessionUser.setUsername(username);
                sessionUser.setEmail(email);
                sessionUser.setPhone(phone);
                sessionUser.setAddress(address);
                sessionUser.setGender(gender);
                sessionUser.setQualification(qualification);
            }

            response.sendRedirect("cadetportal.jsp");
        } else {
            request.setAttribute("errorMessage", "❌ Unable to update your profile. Please try again.");
            request.getRequestDispatcher("editprofile.jsp").forward(request, response);
        }
    }
}
