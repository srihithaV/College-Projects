package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import Dao.CampRegistrationDAO;
import model.CampRegistration;

import java.io.IOException;

/**
 * Servlet implementation class CampRegisterServlet
 */
@WebServlet("/CampRegisterServlet")
public class CampRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public CampRegisterServlet() {
        super();
    }

    /**
     * Handles POST request for camp registration.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Get form parameters
            String campName = request.getParameter("camp_name");
            String regimentalId = request.getParameter("regimental_id");
            String totalAmountStr = request.getParameter("total_amount");
            String status = request.getParameter("status"); // Expected: "Registered"

            if (campName == null || regimentalId == null || totalAmountStr == null || status == null) {
                response.getWriter().println("Missing registration data.");
                return;
            }

            double totalAmount = Double.parseDouble(totalAmountStr);

            // Create CampRegistration object
            CampRegistration registration = new CampRegistration();
            registration.setCampName(campName);
            registration.setRegimentalId(regimentalId);
            registration.setTotalAmount(totalAmount);
            registration.setStatus(status);

            // Save to database
            CampRegistrationDAO dao = new CampRegistrationDAO();
            boolean success = dao.registerCadetForCamp(registration);

            // Redirect on success
            if (success) {
                response.sendRedirect("paymentSuccess.jsp");
            } else {
                response.getWriter().println("Registration failed. Please try again.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Server Error: " + e.getMessage());
        }
    }

    /**
     * Optional GET handler: redirect to registration page (not normally used).
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("campregister.jsp");
    }
}
