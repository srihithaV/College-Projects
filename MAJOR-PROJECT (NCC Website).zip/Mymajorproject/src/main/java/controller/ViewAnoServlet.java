package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import Dao.AddAnoDAO;
import model.AddAno;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.RequestDispatcher;

@WebServlet("/ViewAnoServlet")
public class ViewAnoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ViewAnoServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Fetch ANO list from DAO
        AddAnoDAO dao = new AddAnoDAO();
        List<AddAno> anoList = dao.getAllAnoDetails();  // Ensure this method exists in your DAO

        // Set the list as request attribute
        request.setAttribute("anoList", anoList);

        // Forward to the JSP page to display
        RequestDispatcher dispatcher = request.getRequestDispatcher("viewAno.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
