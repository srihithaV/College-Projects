package controller;

import Dao.CampRegistrationDAO;
import model.CampRegistration;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/AdminCampRegistrationsServlet")  // <-- Updated here
public class AdminCampRegistrationsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        CampRegistrationDAO dao = new CampRegistrationDAO();
        List<CampRegistration> registrations = dao.getCampWiseRegistrationCount();

        request.setAttribute("registrations", registrations);
        request.getRequestDispatcher("campRegistrations.jsp").forward(request, response);
    }
}
