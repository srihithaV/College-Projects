package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.StockItem;

import java.io.IOException;

import Dao.StockDAO;

/**
 * Servlet implementation class AddStockServlet
 */
@WebServlet("/AddStockServlet")
public class AddStockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStockServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
		        throws ServletException, IOException {
		        StockItem item = new StockItem();
		        item.setItemCode(request.getParameter("itemCode"));
		        item.setItemName(request.getParameter("itemName"));
		        item.setTotalQuantity(Integer.parseInt(request.getParameter("totalQuantity")));
		        item.setIssuedQuantity(0); // Default
		        item.setReturnedQuantity(0); // Default
		        item.setCost(Double.parseDouble(request.getParameter("cost")));
		        item.setReceivedDate(request.getParameter("receivedDate"));
		        item.setLifetime(request.getParameter("lifetime"));
		        item.setItemType(request.getParameter("itemType"));

		        boolean inserted = new StockDAO().addStockItem(item);
		        if (inserted) {
		            response.sendRedirect("stockList.jsp");
		        } else {
		            request.setAttribute("errorMessage", "Failed to add item.");
		            request.getRequestDispatcher("addStock.jsp").forward(request, response);
		        }
		    }
}
