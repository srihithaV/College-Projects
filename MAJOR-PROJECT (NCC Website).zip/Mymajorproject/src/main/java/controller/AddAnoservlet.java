package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import model.AddAno;
import Dao.AddAnoDAO;

/**
 * Servlet implementation class AddAnoservlet
 */
@WebServlet("/AddAnoservlet")
public class AddAnoservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddAnoservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String anoid=request.getParameter("ano_id");
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		
		AddAno ano = new AddAno();
		ano.setAnoid(anoid);
		ano.setName(name);
		ano.setPassword(password);
		ano.setEmail(email);
			
		AddAnoDAO anoDAO = new AddAnoDAO();
		boolean isRegistered=anoDAO.addano(ano);
		if (isRegistered) {
            response.sendRedirect("admin.jsp"); // Redirect to login page if successful
        } else {
            response.sendRedirect("AddAno.jsp"); // Redirect back to register page with error
        }
		
		
		
		
	}

}
