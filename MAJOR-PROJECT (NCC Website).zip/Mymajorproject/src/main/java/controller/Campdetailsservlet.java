package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;

import model.Campdetails;
import Dao.CampdetailsDAO;

@WebServlet("/Campdetailsservlet")
public class Campdetailsservlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Campdetailsservlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String campName = request.getParameter("camp_name");
            String startDate = request.getParameter("start_date");
            String endDate = request.getParameter("end_date");
            String location = request.getParameter("location");
            String description = request.getParameter("description");
            double fee = Double.parseDouble(request.getParameter("registrationfee"));

            LocalDate today = LocalDate.now();
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);

            if (start.isBefore(today) || !end.isAfter(start)) {
                response.sendRedirect("campdetails.jsp?status=error");
                return;
            }

            Campdetails camp = new Campdetails();
            camp.setCampName(campName);
            camp.setStartDate(startDate);
            camp.setEndDate(endDate);
            camp.setLocation(location);
            camp.setDescription(description);
            camp.setRegistrationFee(fee);

            CampdetailsDAO cd = new CampdetailsDAO();
            boolean isRegistered = cd.registercamp(camp);

            if (isRegistered) {
                response.sendRedirect("campdetails.jsp?status=success");
            } else {
                response.sendRedirect("campdetails.jsp?status=error");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("campdetails.jsp?status=error");
        }
    }
}
