package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import Dao.UserDAO;
import model.User;

/**
 * Servlet implementation class RejectedCadetsServlet
 */
@WebServlet("/RejectedCadetsServlet")
public class RejectedCadetsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public RejectedCadetsServlet() {
        super();
    }

    /**
     * Handles the GET request to display the rejected cadets
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Create UserDAO instance to interact with the database
        UserDAO userDAO = new UserDAO();

        // Get the list of rejected cadets (status = -1)
        List<User> rejectedCadets = userDAO.getRejectedCadets();

        // Set the list of rejected cadets as a request attribute
        request.setAttribute("rejectedCadets", rejectedCadets);

        // Forward the request to the JSP page to display the rejected cadets
        request.getRequestDispatcher("rejectedCadets.jsp").forward(request, response);
    }

    /**
     * Handles the POST request (if needed, can be used to handle form submissions)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // If needed, handle POST requests here (not necessary for this example)
        doGet(request, response);
    }
}
