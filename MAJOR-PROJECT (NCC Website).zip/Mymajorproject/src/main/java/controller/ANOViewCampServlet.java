package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import model.Campdetails;
import Dao.CampdetailsDAO;

@WebServlet("/ANOViewCampServlet")
public class ANOViewCampServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ANOViewCampServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        CampdetailsDAO dao = new CampdetailsDAO();
        List<Campdetails> allCamps = dao.getAllCamps();

        List<Campdetails> upcomingCamps = new ArrayList<>();
        List<Campdetails> previousCamps = new ArrayList<>();

        LocalDate today = LocalDate.now();

        for (Campdetails camp : allCamps) {
            try {
                LocalDate endDate = LocalDate.parse(camp.getEndDate());
                if (endDate.isBefore(today)) {
                    previousCamps.add(camp);
                } else {
                    upcomingCamps.add(camp);
                }
            } catch (Exception e) {
                System.err.println("Date parsing error for camp: " + camp.getCampName());
                e.printStackTrace();
            }
        }

        request.setAttribute("upcomingCamps", upcomingCamps);
        request.setAttribute("previousCamps", previousCamps);

        RequestDispatcher dispatcher = request.getRequestDispatcher("Anoviewcamps.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
