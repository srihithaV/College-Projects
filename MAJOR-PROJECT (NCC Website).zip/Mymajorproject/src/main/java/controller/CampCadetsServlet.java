package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.User;
import Dao.UserDAO;

import java.io.IOException;
import java.util.List;

@WebServlet("/CampCadetsServlet")
public class CampCadetsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public CampCadetsServlet() {
        super();
    }

    /**
     * Handles GET requests to show cadets for a selected camp.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get camp name from request parameter
        String campName = request.getParameter("campName");

        if (campName != null && !campName.trim().isEmpty()) {
            // Fetch cadets registered for the selected camp
            UserDAO userDAO = new UserDAO();
            List<User> cadets = userDAO.getCadetsByCampName(campName);

            // Set attributes for JSP
            request.setAttribute("campName", campName);
            request.setAttribute("cadets", cadets);

            // Forward to JSP to display the cadet list
            request.getRequestDispatcher("campCadets.jsp").forward(request, response);
        } else {
            // If campName is missing, redirect back or show error
            request.setAttribute("errorMessage", "Camp name is missing or invalid.");
            request.getRequestDispatcher("campRegistrations.jsp").forward(request, response);
        }
    }

    /**
     * Forward POST requests to GET handler.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
