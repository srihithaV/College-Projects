 package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.RequestDispatcher;

import java.io.IOException;
import java.util.List;

import model.Campdetails;
import model.User;
import Dao.CampdetailsDAO;
import Dao.CampRegistrationDAO;

@WebServlet("/ViewCampServlet")
public class ViewCampServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ViewCampServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CampdetailsDAO campDao = new CampdetailsDAO();
        CampRegistrationDAO regDao = new CampRegistrationDAO();

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        String selectedCampName = request.getParameter("selectedCampName");
        List<Campdetails> camps = campDao.getAllCamps();

        Campdetails selectedCamp = null;
        boolean isAlreadyRegistered = false;

        if (selectedCampName != null) {
            for (Campdetails c : camps) {
                if (c.getCampName().equals(selectedCampName)) {
                    selectedCamp = c;
                    break;
                }
            }

            if (user != null && selectedCamp != null) {
                String regimentalId = user.getRegimental_id();
                isAlreadyRegistered = regDao.isCadetAlreadyRegistered(regimentalId, selectedCampName);
            }
        }

        request.setAttribute("camps", camps);
        request.setAttribute("selectedCampName", selectedCampName);
        request.setAttribute("selectedCamp", selectedCamp);
        request.setAttribute("isAlreadyRegistered", isAlreadyRegistered);

        RequestDispatcher dispatcher = request.getRequestDispatcher("viewcamps.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}