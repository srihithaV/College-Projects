package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.User;
import Dao.UserDAO;
import Dao.AddAnoDAO;

import java.io.IOException;
import java.util.Optional;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        UserDAO userDAO = new UserDAO();
        AddAnoDAO anoDAO = new AddAnoDAO();

        if ("Admin".equalsIgnoreCase(role)) {
            if ("admin1".equals(username) && "123".equals(password)) {
                request.setAttribute("successMessage", "✔️ Successfully logged in as Admin.");
                response.sendRedirect("admin.jsp");
            } else {
                request.setAttribute("errorMessage", "❌ Invalid admin credentials.");
                request.getRequestDispatcher("login.html").forward(request, response);
            }
        } else if ("ANO".equalsIgnoreCase(role)) {
            if (anoDAO.validateAno(username, password)) {
                request.getSession().setAttribute("anoUser", username);
                request.setAttribute("successMessage", "✔️ Successfully logged in as ANO.");
                response.sendRedirect("ANOinterface.jsp");
            } else {
                request.setAttribute("errorMessage", "❌ Invalid ANO credentials.");
                request.getRequestDispatcher("login.html").forward(request, response);
            }
        } else if ("Cadet".equalsIgnoreCase(role)) {
            User user = userDAO.loginUser(username, password);
            if (user != null) {
                // DEBUG PRINT (Optional): Remove in production
                System.out.println("Login attempt by: " + user.getUsername() + " | Status: " + user.getStatus());

                if (user.getStatus() == 1) {
                    Optional<User> userOptional = userDAO.findUserByUsername(username);
                    if (userOptional.isPresent()) {
                        User loginUser = userOptional.get();
                        loginUser.setPassword(null); // Hide password in session
                        request.getSession().setAttribute("user", loginUser);
                        response.sendRedirect("cadetportal.jsp");
                    } else {
                        request.setAttribute("errorMessage", "❌ User not found.");
                        request.getRequestDispatcher("login.html").forward(request, response);
                    }
                } else {
                    request.setAttribute("errorMessage", "❌ Your registration is pending or rejected. Contact your ANO.");
                    request.getRequestDispatcher("login.html").forward(request, response);
                }
            } else {
                request.setAttribute("errorMessage", "❌ Invalid cadet credentials.");
                request.getRequestDispatcher("login.html").forward(request, response);
            }
        } else {
            request.setAttribute("errorMessage", "❌ Invalid role selected.");
            request.getRequestDispatcher("login.html").forward(request, response);
        }
    }
}
