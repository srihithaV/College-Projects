package Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;

import model.EditableUser;
import model.User;
public class UserDAO {
	private final String jdbcURL = "jdbc:mysql://localhost:3306/project";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = ""; 
    private static final String INSERT_USER_QUERY = "INSERT INTO users(name,email,password,regimental_id,phone,address,gender,qualification) VALUES (?,?,?,?,?,?,?,?)";
    private static final String SELECT_USER_BY_USERNAME = "SELECT * FROM users WHERE name = ?";
    public boolean registerUser(User user) {
        boolean isRegistered = false;

        try {
            // Explicitly load the MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish database connection
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            // Prepare the SQL query
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USER_QUERY);
            

            // Set parameters for the query
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getEmail());
            preparedStatement.setString(3, user.getPassword());
            preparedStatement.setString(4, user.getRegimental_id());
            preparedStatement.setString(5, user.getPhone());
            preparedStatement.setString(6, user.getAddress());
            preparedStatement.setString(7, user.getGender());
            preparedStatement.setString(8, user.getQualification());
            
            

            // Execute the update
            int rowsAffected = preparedStatement.executeUpdate();
            isRegistered = rowsAffected > 0;
            System.out.print(rowsAffected);

            // Close resources
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection or query execution error.");
            e.printStackTrace();
        }

        return isRegistered;
       
    }
    
    
    public User loginUser(String username, String password) {
        User user = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            // Prepare SQL query
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_USERNAME);
            preparedStatement.setString(1, username);

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if the username exists and the password matches
            if (resultSet.next()) {
                String dbPassword = resultSet.getString("password");
                if (dbPassword.equals(password)) {
                    // Create User object and set its data
                    user = new User();
                    user.setUsername(resultSet.getString("name"));
                    user.setPassword(dbPassword);
                    user.setStatus(resultSet.getInt("status")); // ✅ This ensures status check works
//                    System.out.print(user.toString());      
                }
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection or query execution error.");
            e.printStackTrace();
        }

        return user;
    }
    
    
    public Optional<User> findUserByUsername(String username) {
        // Define the SQL query to fetch user by username
        String query = "SELECT * FROM users WHERE name = ?";
        
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword );
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            
            // Set the username parameter in the query
            preparedStatement.setString(1, username);
            
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    // If user found, map the result to a User object
                    User user = new User();
                    user.setId(resultSet.getInt("id"));
                    user.setUsername(resultSet.getString("name"));
                    user.setEmail(resultSet.getString("email"));
                    user.setPassword(resultSet.getString("password"));
                    user.setRegimental_id(resultSet.getString("regimental_id"));
                    user.setPhone(resultSet.getString("phone"));
                    user.setAddress(resultSet.getString("address"));
                    user.setGender(resultSet.getString("gender"));
                    user.setQualification(resultSet.getString("qualification"));
                    System.out.println("from dao:" + user);
//                    user.setRole(resultSet.getString("role"));
                    
                    // Return user wrapped in Optional
                    return Optional.of(user);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception properly, maybe log it
        }
        
        // If no user found, return an empty Optional
        return Optional.empty();
    }
    
	
	
    
    
 // Get pending cadets (status = 0)
    public List<User> getPendingCadets() {
        List<User> cadets = new ArrayList<>();
        String query = "SELECT * FROM users WHERE status = 0";

        try
        {
        	 Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setRegimental_id(rs.getString("regimental_id"));
                user.setGender(rs.getString("gender"));
                user.setPhone(rs.getString("phone"));
                cadets.add(user);
            }
             

        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();}
        
        System.out.println("Pending Cadets Size: " + cadets.size()); // Debugging line
        return cadets;
    }

    // Update cadet status: Accept = 1, Reject = -1
    public boolean updateCadetStatus(int id, int status) {
        String query = "UPDATE users SET status = ? WHERE id = ?";
        boolean rowUpdated = false;

        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, status);
            ps.setInt(2, id);
            rowUpdated = ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rowUpdated;
    }
    
    
 // Get accepted cadets (status = 1)
    public List<User> getAcceptedCadets() {
        List<User> acceptedCadets = new ArrayList<>();
        String query = "SELECT * FROM users WHERE status = 1";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setRegimental_id(rs.getString("regimental_id"));
                user.setGender(rs.getString("gender"));
                user.setPhone(rs.getString("phone"));
                //user.setStatus(rs.getInt("status"));
                acceptedCadets.add(user);
            }

            rs.close();
            ps.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return acceptedCadets;
    }

    
    
 // Get rejected cadets (status = -1)
    public List<User> getRejectedCadets() {
        List<User> cadets = new ArrayList<>();
        String query = "SELECT * FROM users WHERE status = -1";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setRegimental_id(rs.getString("regimental_id"));
                user.setGender(rs.getString("gender"));
                user.setPhone(rs.getString("phone"));
                cadets.add(user);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        }

        System.out.println("Rejected Cadets Size: " + cadets.size()); // Debugging line
        return cadets;
    }

    
    


    // ✅ NEW METHODS FOR PIE CHART DATA

    public int getAcceptedCount() {
        return getCountByStatus(1);
    }

    public int getRejectedCount() {
        return getCountByStatus(-1);
    }

    public int getTotalEnrolledCount() {
        String query = "SELECT COUNT(*) FROM users WHERE status IN (-1, 0, 1)";
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private int getCountByStatus(int status) {
        String query = "SELECT COUNT(*) FROM users WHERE status = ?";
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    
    public boolean updateUserProfile(EditableUser updatedUser) {
        String sql = "UPDATE users SET name = ?,email = ?,phone = ?,address = ?,gender = ?,qualification = ? WHERE id = ?";
        
        Connection connection = null;
        PreparedStatement stmt = null;

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish the database connection
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            
            // Prepare the SQL statement
            stmt = connection.prepareStatement(sql);
            
            // Set the parameters for the SQL query
            stmt.setString(1, updatedUser.getUsername());
            stmt.setString(2, updatedUser.getEmail());
            stmt.setString(3, updatedUser.getPhone());
            stmt.setString(4, updatedUser.getAddress());
            stmt.setString(5, updatedUser.getGender());
            stmt.setString(6, updatedUser.getQualification());
            stmt.setInt(7, updatedUser.getId());

            // Execute the update and check the number of affected rows
            int rowsUpdated = stmt.executeUpdate();

            // Return true if at least one row was updated, otherwise return false
            return rowsUpdated > 0;
        } catch (ClassNotFoundException e) {
            // Handle class not found exception (JDBC driver issue)
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
            return false; // Return false if there's an error
        } catch (SQLException e) {
            // Handle SQL exception (issues with the database connection or query)
            System.err.println("Error while updating user profile.");
            e.printStackTrace();
            return false; // Return false if there's an error
        } finally {
            // Clean up database resources (connection and statement)
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println("Error while closing database resources.");
                e.printStackTrace();
            }
        }
    }
    
    
    
    public List<User> getCadetsByCampName(String campName) {
        List<User> cadets = new ArrayList<>();
        String sql = "SELECT u.* FROM users u " +
                     "JOIN camp_registrations cr ON u.regimental_id = cr.regimental_id " +
                     "WHERE cr.camp_name = ?";

        try {
        	 Class.forName("com.mysql.cj.jdbc.Driver");
             
             // Establish the database connection
             
             
        	 Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = connection.prepareStatement(sql); 
            
            stmt.setString(1, campName);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("name")); // Or "username" if column name is different
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setAddress(rs.getString("address"));
                user.setGender(rs.getString("gender"));
                user.setQualification(rs.getString("qualification"));
                user.setRegimental_id(rs.getString("regimental_id"));
                cadets.add(user);
            }
        } 
        catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        }
         catch (SQLException e) {
            e.printStackTrace();
        }

        return cadets;
    }
    
    public String getNameByCadetId(String cadetId) {
        String name = "";
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	 Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String query = "SELECT name FROM users WHERE regimental_id = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, cadetId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                name = rs.getString("name");
            }
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return name;
    }



    
}
