package Dao;
import model.Item;
import java.sql.*;
import model.IssuedItem;

public class ItemDAO {
	private final String jdbcURL = "jdbc:mysql://localhost:3306/project";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "";

    // Method to issue item
    public boolean issueItem(IssuedItem item) {
    	
        boolean isSuccess = false;
        try {
            // Establish connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            // Insert query to add issued item details to the issued_items table
            String query = "INSERT INTO issued_items (cadet_id, name, item_name, quantity, return_date, remarks, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(query);

            // Use getters from the IssuedItem object
            ps.setString(1, item.getCadetId());
            ps.setString(2, item.getName());
            ps.setString(3, item.getItemName());
            ps.setInt(4, item.getQuantity());
            ps.setDate(5, item.getReturnDate()); // java.sql.Date expected
            ps.setString(6, item.getRemarks());
            ps.setString(7, item.getStatus()); // "not returned"

            int result = ps.executeUpdate();

            if (result > 0) {
                // If item issuance is successful, update the stock
                updateItemStock(item.getItemName(), item.getQuantity());
                isSuccess = true;
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
        }

    // Method to update stock after issuing an item
    private void updateItemStock(String itemName, int quantity) {
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
          	 Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String query = "UPDATE items SET issued_items = issued_items + ?, items_left = items_left - ? WHERE item_name = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, quantity);
            ps.setInt(2, quantity);
            ps.setString(3, itemName);

            ps.executeUpdate();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to mark an item as returned and update stock
    public boolean returnItem(int itemId) {
        boolean isSuccess = false;
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
          	 Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String query = "UPDATE issued_items SET status = 'returned' WHERE id = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, itemId);
            int result = ps.executeUpdate();
            
            if (result > 0) {
                // Get the item name and quantity to update stock
                String itemName = getItemNameById(itemId);
                int quantity = getItemQuantityById(itemId);
                
                // Update the stock
                updateReturnStock(itemName, quantity);
                isSuccess = true;
            }
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    // Method to update stock when an item is returned
    private void updateReturnStock(String itemName, int quantity) {
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
          	 Connection con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String query = "UPDATE items SET issued_items = issued_items - ?, items_left = items_left + ? WHERE item_name = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, quantity);
            ps.setInt(2, quantity);
            ps.setString(3, itemName);

            ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to get item name by issued item ID
    private String getItemNameById(int itemId) {
        String itemName = "";
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
          	 Connection con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String query = "SELECT item_name FROM issued_items WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, itemId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                itemName = rs.getString("item_name");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return itemName;
    }

    // Method to get quantity by issued item ID
    private int getItemQuantityById(int itemId) {
        int quantity = 0;
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
          	 Connection con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String query = "SELECT quantity FROM issued_items WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, itemId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                quantity = rs.getInt("quantity");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return quantity;
    }
}

