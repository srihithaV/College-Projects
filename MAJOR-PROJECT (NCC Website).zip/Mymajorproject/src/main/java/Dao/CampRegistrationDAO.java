package Dao;

import model.CampRegistration;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
public class CampRegistrationDAO {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/project";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "";

    public boolean registerCadetForCamp(CampRegistration reg) {
        String query = "INSERT INTO camp_registrations (camp_name, regimental_id, total_amount, status) VALUES (?, ?, ?, ?)";
        boolean inserted = false;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, reg.getCampName());
            ps.setString(2, reg.getRegimentalId());
            ps.setDouble(3, reg.getTotalAmount());
            ps.setString(4, reg.getStatus());

            inserted = ps.executeUpdate() > 0;

            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return inserted;
    }
    
    public boolean isCadetAlreadyRegistered(String regimentalId, String campName) {
        String query = "SELECT * FROM camp_registrations WHERE regimental_id = ? AND camp_name = ? AND status = 'Registered'";
        boolean exists = false;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, regimentalId);
            ps.setString(2, campName);
            ResultSet rs = ps.executeQuery();

            exists = rs.next(); // If any result exists, registration exists

            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return exists;
    }
    
    public List<CampRegistration> getRegisteredCampsForCadet(String regimentalId) {
        List<CampRegistration> camps = new ArrayList<>();
        String query = "SELECT cd.camp_name, cd.start_date, cd.end_date " +
                       "FROM camp_registrations cr " +
                       "JOIN campdetails cd ON cr.camp_name = cd.camp_name " +
                       "WHERE cr.regimental_id = ? AND cr.status = 'Registered' " +
                       "ORDER BY cd.start_date DESC";  // <-- DESCENDING order

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, regimentalId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                CampRegistration camp = new CampRegistration();
                camp.setCampName(rs.getString("camp_name"));
                camp.setStartDate(rs.getDate("start_date"));
                camp.setEndDate(rs.getDate("end_date"));
                camps.add(camp);
            }

            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return camps;
    }

   
    
    public List<CampRegistration> getCampWiseRegistrationCount() {
        List<CampRegistration> registrations = new ArrayList<>();
        String query = "SELECT c.camp_name, COUNT(r.id) AS cadet_count " +
                       "FROM campdetails c " +
                       "LEFT JOIN camp_registrations r ON c.camp_name = r.camp_name AND r.status = 'Registered' " +
                       "GROUP BY c.camp_name";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                CampRegistration reg = new CampRegistration();
                reg.setCampName(rs.getString("camp_name"));
                reg.setCadetCount(rs.getInt("cadet_count"));

                registrations.add(reg);
            }

            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return registrations;
    }



}

