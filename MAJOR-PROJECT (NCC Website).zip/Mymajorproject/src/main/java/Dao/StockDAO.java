package Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import model.StockItem;

import java.util.ArrayList;
public class StockDAO {
	 private final String jdbcURL = "jdbc:mysql://localhost:3306/project";
	    private final String jdbcUsername = "root";
	    private final String jdbcPassword = "";

	public boolean addStockItem(StockItem item) {
	    String sql = "INSERT INTO stock_items (item_code, item_name, total_quantity, issued_quantity, returned_quantity, cost, received_date, lifetime, item_type) " +
	                 "VALUES (?, ?, ?, 0, 0, ?, ?, ?, ?)";
	    try {
	    	 Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
	            PreparedStatement ps = connection.prepareStatement(sql);
	        ps.setString(1, item.getItemCode());
	        ps.setString(2, item.getItemName());
	        ps.setInt(3, item.getTotalQuantity());
	        ps.setDouble(4, item.getCost());
	        ps.setString(5, item.getReceivedDate());
	        ps.setString(6, item.getLifetime());
	        ps.setString(7, item.getItemType());
	        return ps.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        }
	    return false;
	}
	
	public List<StockItem> getAllStockItems() {
	    List<StockItem> itemList = new ArrayList<>();
	    String sql = "SELECT * FROM stock_items";
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
	        PreparedStatement ps = connection.prepareStatement(sql);
	        ResultSet rs = ps.executeQuery();
	        while (rs.next()) {
	            StockItem item = new StockItem();
	            item.setId(rs.getInt("id"));
	            item.setItemCode(rs.getString("item_code"));
	            item.setItemName(rs.getString("item_name"));
	            item.setTotalQuantity(rs.getInt("total_quantity"));
	            item.setIssuedQuantity(rs.getInt("issued_quantity"));
	            item.setReturnedQuantity(rs.getInt("returned_quantity"));
	            item.setCost(rs.getDouble("cost"));
	            item.setReceivedDate(rs.getString("received_date"));
	            item.setLifetime(rs.getString("lifetime"));
	            item.setItemType(rs.getString("item_type"));
	            itemList.add(item);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return itemList;
	}


}
