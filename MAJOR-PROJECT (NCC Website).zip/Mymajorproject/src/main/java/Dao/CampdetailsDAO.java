package Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import model.Campdetails;
import java.util.List;
import java.util.ArrayList;



public class CampdetailsDAO {
	private final String jdbcURL = "jdbc:mysql://localhost:3306/project";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = ""; 
   private static final String INSERT_CAMP_QUERY = "INSERT INTO campdetails(camp_name,start_date,end_date,location,description,registration_fee) VALUES (?,?,?,?,?,?)";
    public boolean registercamp(Campdetails camp)
    {
    	boolean isRegistered = false;

        try {
            // Explicitly load the MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish database connection
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CAMP_QUERY);
            preparedStatement.setString(1, camp.getCampName());
            preparedStatement.setString(2, camp.getStartDate());
            preparedStatement.setString(3, camp.getEndDate());
            preparedStatement.setString(4, camp.getLocation());
            preparedStatement.setString(5, camp.getDescription());
            preparedStatement.setDouble(6, camp.getRegistrationFee());
            int rowsAffected = preparedStatement.executeUpdate();
            isRegistered = rowsAffected > 0;
            System.out.print(rowsAffected);

            // Close resources
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection or query execution error.");
            System.err.println("Database error: " + e.getMessage());
            e.printStackTrace();
        }

        return isRegistered;
       
    }
    
    public List<Campdetails> getAllCamps() {
        List<Campdetails> camps = new ArrayList<>();
        String query = "SELECT * FROM campdetails";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Campdetails camp = new Campdetails();
                camp.setCampName(rs.getString("camp_name"));
                camp.setStartDate(rs.getString("start_date"));
                camp.setEndDate(rs.getString("end_date"));
                camp.setLocation(rs.getString("location"));
                camp.setDescription(rs.getString("description"));
                camp.setRegistrationFee(rs.getDouble("registration_fee"));
                camps.add(camp);
            }
            //System.out.println("Camps from DB: " + camps);
            rs.close();
            stmt.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return camps;
    }

            

    }

