package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import model.AddAno;

public class AddAnoDAO {

    private final String jdbcURL = "jdbc:mysql://localhost:3306/project";
    private final String jdbcUsername = "root";
    private final String jdbcPassword = "";

    // Method to add a new ANO to the database
    public boolean addano(AddAno ano) {
        boolean isRegistered = false;
        String INSERT_USER_QUERY = "INSERT INTO ano(ano_id, name, password, email) VALUES (?, ?, ?, ?)";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USER_QUERY);
            preparedStatement.setString(1, ano.getAnoid());
            preparedStatement.setString(2, ano.getName());
            preparedStatement.setString(3, ano.getPassword());
            preparedStatement.setString(4, ano.getEmail());

            int rowsAffected = preparedStatement.executeUpdate();
            isRegistered = rowsAffected > 0;

            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database connection or query execution error.");
            e.printStackTrace();
        }

        return isRegistered;
    }

    // Method to validate ANO login credentials
    public boolean validateAno(String username, String password) {
        boolean isValid = false;
        String SELECT_QUERY = "SELECT * FROM ano WHERE name = ? AND password = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                isValid = true;
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database query error.");
            e.printStackTrace();
        }

        return isValid;
    }
    
    
    
    
    public List<AddAno> getAllAnoDetails() {
        List<AddAno> anoList = new ArrayList<>();
        String SELECT_ALL_ANOS = "SELECT * FROM ano";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_ANOS);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                AddAno ano = new AddAno();
                ano.setAnoid(resultSet.getString("ano_id"));
                ano.setName(resultSet.getString("name"));
                ano.setPassword(resultSet.getString("password"));
                ano.setEmail(resultSet.getString("email"));
                anoList.add(ano);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return anoList;
    }

    
    
}